package com.wedog.webdog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebDogApplicationTests {

	@Test
	void contextLoads() {
	}

}
